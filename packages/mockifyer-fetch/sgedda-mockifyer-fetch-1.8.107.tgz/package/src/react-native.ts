/**
 * React Native/Expo Helper Functions
 * 
 * Simplified setup for React Native applications with automatic
 * conditional provider selection (FileSystem in dev, Memory in prod)
 */

import { canUseDashboardRedisProxy } from './utils/dashboard-redis-health';
import { setupMockifyer } from './index';
import { MemoryProvider, ExpoFileSystemProvider, MockData, HTTPClient, setScenarioLaunchOverride } from '@sgedda/mockifyer-core';
import {
  logger,
  MOCKIFYER_LAUNCH_ARGUMENT_CLIENT_ID_KEY,
  tryGetClientIdFromLaunchArguments,
  tryGetScenarioFromLaunchArguments,
  resolveMockifyerRuntimeMode,
  logMockifyerNotActivated,
  resolveRecordResponses,
  resolveStrictScenarioResolution,
  resolveRuntimeEnabledStorage,
  loadPersistedRuntimeEnabled,
  shouldActivateMockifyerForReactNative,
  type MockifyerRuntimeMode,
  type MockifyerRuntimeEnabledStorage,
} from '@sgedda/mockifyer-core';

// React Native package-root resolution points at this entry. Keep the root
// public API available for apps that import from '@sgedda/mockifyer-fetch'.
export { setupMockifyer } from './index';
export * from '@sgedda/mockifyer-core';

// Re-export MockifyerInstance type to avoid circular dependency
export interface MockifyerInstance extends HTTPClient {
  reloadMockData: (syncFromProject?: boolean) => Promise<void>;
  clearStaleCacheEntries: () => number;
  clearAllMocks: () => Promise<void>;
  setClientId: (lane: string) => void;
  getClientId: () => string | undefined;
  setRecordMode: (enabled: boolean) => void;
  isRecordMode: () => boolean;
  setRecordResponses: (enabled: boolean) => void;
  isRecordResponses: () => boolean;
  enableMockifyer: () => void;
  disableMockifyer: () => void;
  isMockifyerEnabled: () => boolean;
}

/**
 * Outcome of {@link setupMockifyerForReactNative}.
 *
 * - **`not_activated`** — `fetch` was not patched this run (see **`MOCKIFYER_MODE`** / `runtimeMode`: `off`, or `launch_client` without a launch-arg lane or scenario).
 *   Not the same as “permanently off” unless mode is **`off`** (then launch args do not activate).
 * - **`active`** — Mockifyer initialized and patched `global.fetch`.
 * - **`failed_no_bundled_mocks`** — Activation criteria were met and `isDev` was false, but bundled mock data was missing or empty.
 */
export type MockifyerReactNativeInitStatus =
  | 'not_activated'
  | 'active'
  | 'failed_no_bundled_mocks';

export type SetupMockifyerForReactNativeResult =
  | { readonly status: 'not_activated'; readonly instance: null }
  | { readonly status: 'failed_no_bundled_mocks'; readonly instance: null }
  | { readonly status: 'active'; readonly instance: MockifyerInstance };

/**
 * Type guard: `true` when {@link setupMockifyerForReactNative} patched `fetch` and returned an instance.
 */
export function isMockifyerReactNativeActive(
  result: SetupMockifyerForReactNativeResult
): result is { readonly status: 'active'; readonly instance: MockifyerInstance } {
  return result.status === 'active';
}

export interface ReactNativeMockifyerConfig {
  /** Whether we're in development mode (determines which provider to use) */
  isDev: boolean;
  /** Path to mock data directory (used in development) */
  mockDataPath?: string;
  /** Path to bundled mock data file (used in production) */
  bundledDataPath?: string;
  /** Enable recording mode (development only) */
  recordMode?: boolean;
  /**
   * When true, Mockifyer starts disabled (all requests bypass).
   * Use `instance.enableMockifyer()` to turn it on via GUI.
   * 
   * **Prefer `runtimeMode: 'manual'`** for clearer intent.
   * 
   * Default: false (starts enabled).
   */
  startDisabled?: boolean;
  /**
   * Persist enable/disable across app restarts (AsyncStorage when `true`).
   * With `runtimeMode: 'manual'`, first launch is off; after the user enables,
   * the next launch stays on.
   */
  persistRuntimeEnabled?: boolean | MockifyerRuntimeEnabledStorage;
  /**
   * When true, reads `scenario` from `react-native-launch-arguments` (optional peer).
   * Highest priority over MOCKIFYER_SCENARIO, config.scenarios, Metro scenario sync, and scenario-config.json.
   * When a launch `scenario` is present, Mockifyer **activates** (also under `launch_client`, no lane needed),
   * **starts enabled** (even with `runtimeMode: 'manual'`), and sends it as the dashboard proxy scenario
   * (unless `proxyScenario` is set). `runtimeMode: 'off'` still wins.
   * Set to `false` to ignore launch scenario args entirely.
   * Default: auto-detect when a non-empty launch `scenario` is present.
   */
  useLaunchArgumentsScenario?: boolean;
  /**
   * Sets the same highest-priority scenario as {@link useLaunchArgumentsScenario} when you pass the value yourself
   * (e.g. after reading launch args). Ignored if empty after trim.
   */
  defaultScenario?: string;
  /** Additional Mockifyer config options */
  config?: Partial<Parameters<typeof setupMockifyer>[0]>;
  /** Optional: route real network calls through a proxy service (e.g. mockifyer-dashboard in Redis mode) */
  proxyBaseUrl?: string;
  /** Optional: force proxy scenario */
  proxyScenario?: string;
  /**
   * Optional: record responses on proxy cache miss (proxy must support recording).
   * Deprecated: prefer using `recordMode` when `proxyBaseUrl` is provided.
   */
  proxyRecordOnMiss?: boolean;
  /**
   * When false, dashboard proxy stores request-only stubs on cache miss (Responses: Off).
   * Defaults to `false`. Env **`MOCKIFYER_RECORD_RESPONSES`** overrides when set.
   */
  proxyRecordResponses?: boolean;
  /**
   * When true, skip `GET /api/health` and always wire dashboard proxy (same as Node preset).
   */
  skipDashboardRedisHealthCheck?: boolean;
  /**
   * When true, read `clientId` from Maestro/native launch arguments (optional peer `react-native-launch-arguments`).
   * Prefer this over passing scenario from E2E if the dashboard/Redis should control scenario on the fly for that lane.
   * Forwards to {@link MockifyerConfig.useLaunchArgumentsClientId} on the merged config passed to `setupMockifyer`.
   *
   * If the launch argument is **set** (non-empty) for {@link launchArgumentClientIdKey}, the lane id is applied when Mockifyer activates (see **`runtimeMode`** / **`MOCKIFYER_MODE`**; with **`launch_client`**, a set arg is required to activate).
   */
  useLaunchArgumentsClientId?: boolean;
  /** Launch-argument key for the client lane id (default: `mockifyerClientId`). */
  launchArgumentClientIdKey?: string;
  /**
   * When Mockifyer may patch `fetch` at startup. Overrides **`MOCKIFYER_MODE`** env and `config.runtimeMode`.
   * Prefer env **`MOCKIFYER_MODE`**: `off` | `on` | `launch_client` | `manual`.
   * 
   * Use **`manual`** to patch but start disabled (enable via GUI toggle).
   * Aliases: `e2e`, `maestro` → `launch_client`; `gui`, `toggle` → `manual`.
   */
  runtimeMode?: MockifyerRuntimeMode;
}

/**
 * Apply scenario from launch arguments and/or defaultScenario (highest priority in getCurrentScenario).
 * @returns The native launch-argument `scenario` when one was applied (activates Mockifyer, forces runtime toggle on,
 *   and is sent as the proxy scenario); otherwise `undefined`.
 */
function applyReactNativeScenarioOptions(options: ReactNativeMockifyerConfig): string | undefined {
  // Auto-detect launch `scenario` when present (E2E). Opt out with useLaunchArgumentsScenario: false.
  if (options.useLaunchArgumentsScenario !== false) {
    const scenarioFromLaunch = tryGetScenarioFromLaunchArguments();
    if (scenarioFromLaunch) {
      setScenarioLaunchOverride(scenarioFromLaunch, { fromLaunchArguments: true });
      return scenarioFromLaunch;
    }
  }

  if (options.defaultScenario !== undefined && options.defaultScenario !== null) {
    const t = String(options.defaultScenario).trim();
    if (t !== '') {
      // App config default — not a native launch arg; do not force runtime toggle on.
      setScenarioLaunchOverride(t);
    }
  }

  return undefined;
}

// Lazy load bundled data (only used in production builds)
let bundledMockData: MockData[] | null = null;

/**
 * Load bundled mock data from a TypeScript/JavaScript module
 *
 * Note: For React Native/Metro, we need to handle dynamic imports differently
 * Metro doesn't support dynamic require() with variables, so we use a workaround
 */
async function loadBundledMockData(bundledDataPath: string): Promise<MockData[]> {
  if (bundledMockData) {
    return bundledMockData;
  }

  try {
    // Metro bundler doesn't support dynamic require() with variables
    // We use eval with a fully constructed string to avoid Metro's static analysis
    // This bypasses Metro's static analysis completely
    const r = 'r';
    const e = 'e';
    const q = 'q';
    const u = 'u';
    const i = 'i';
    const req = r + e + q + u + i + r + e;
    // eslint-disable-next-line no-eval
    const module = eval(`${req}(${JSON.stringify(bundledDataPath)})`);
    
    const data = Array.isArray(module.mockData) 
      ? module.mockData 
      : [module.mockData];
    
    bundledMockData = data;
    return data;
  } catch (error) {
    logger.warn('[Mockifyer] Could not load bundled mock data:', error);
    return [];
  }
}

/**
 * Setup Mockifyer for React Native/Expo with automatic conditional provider selection
 * 
 * - Development (isDev === true): Uses Expo FileSystem provider - can record mocks
 * - Production (isDev === false): Uses Memory provider with bundled TypeScript file
 * 
 * @example
 * ```typescript
 * import { setupMockifyerForReactNative } from '@sgedda/mockifyer-fetch/react-native';
 *
 * // MOCKIFYER_MODE=on | launch_client | off — default when unset is on; use launch_client for Maestro-only activation.
 * const result = await setupMockifyerForReactNative({
 *   isDev: __DEV__, // Selects Hybrid vs Memory provider once enabled
 *   mockDataPath: 'mock-data',
 *   bundledDataPath: './assets/mock-data',
 *   recordMode: process.env.MOCKIFYER_RECORD === 'true',
 *   useLaunchArgumentsScenario: true, // optional: scenario from react-native-launch-arguments (highest priority)
 * });
 * // result.status: 'not_activated' | 'active' | 'failed_no_bundled_mocks'
 * ```
 */
export async function setupMockifyerForReactNative(
  options: ReactNativeMockifyerConfig
): Promise<SetupMockifyerForReactNativeResult> {
  const {
    isDev,
    mockDataPath = 'mock-data',
    bundledDataPath = './assets/mock-data',
    recordMode = false,
    startDisabled = false,
    persistRuntimeEnabled,
    config: userConfig = {},
    proxyBaseUrl,
    proxyScenario,
    proxyRecordOnMiss,
    proxyRecordResponses,
    skipDashboardRedisHealthCheck,
    useLaunchArgumentsClientId = false,
    launchArgumentClientIdKey = MOCKIFYER_LAUNCH_ARGUMENT_CLIENT_ID_KEY,
    runtimeMode: runtimeModeOption,
  } = options;

  const proxyShouldRecordOnMiss = proxyRecordOnMiss ?? recordMode;
  const proxyShouldRecordResponses = resolveRecordResponses(
    proxyRecordResponses ?? userConfig.proxy?.recordResponses
  );

  const launchClientIdKey =
    launchArgumentClientIdKey ?? MOCKIFYER_LAUNCH_ARGUMENT_CLIENT_ID_KEY;
  const clientIdFromLaunchArgs = tryGetClientIdFromLaunchArguments(launchClientIdKey);
  const shouldApplyLaunchClientId =
    useLaunchArgumentsClientId || Boolean(clientIdFromLaunchArgs);

  const resolvedRuntimeMode = resolveMockifyerRuntimeMode({
    configMode: runtimeModeOption ?? userConfig.runtimeMode,
  });

  const persistOption = persistRuntimeEnabled ?? userConfig.persistRuntimeEnabled;
  const runtimeEnabledStorage = resolveRuntimeEnabledStorage(persistOption);
  let initialRuntimeEnabled: boolean | undefined = userConfig.initialRuntimeEnabled;
  if (runtimeEnabledStorage && typeof initialRuntimeEnabled !== 'boolean') {
    const saved = await loadPersistedRuntimeEnabled(runtimeEnabledStorage);
    if (typeof saved === 'boolean') {
      initialRuntimeEnabled = saved;
    }
  }

  // Apply scenario launch override early so we know if E2E forced a scenario.
  const launchScenario = applyReactNativeScenarioOptions(options);
  const launchScenarioApplied = launchScenario !== undefined;
  // Launch `scenario` travels on every dashboard proxy request (body override wins over lane / global scenario),
  // so E2E does not need a lane mapped in the dashboard. An explicit `proxyScenario` still wins.
  const effectiveProxyScenario = proxyScenario ?? launchScenario;
  if (launchScenarioApplied) {
    // Launch `scenario` arg → start enabled (wins over persisted off for this session).
    initialRuntimeEnabled = true;
    logger.info(
      '[Mockifyer] Launch argument scenario present — starting with Mockifyer ENABLED'
    );
  }

  const mergedConfig: typeof userConfig = {
    ...userConfig,
    runtimeMode: resolvedRuntimeMode,
    ...(persistOption !== undefined ? { persistRuntimeEnabled: persistOption } : {}),
    ...(typeof initialRuntimeEnabled === 'boolean' ? { initialRuntimeEnabled } : {}),
    ...(shouldApplyLaunchClientId
      ? {
          useLaunchArgumentsClientId: true as const,
          launchArgumentClientIdKey: launchClientIdKey,
        }
      : {}),
  };

  const devInitHeadline = (strictProxy: boolean, strictProxyOnlyFallback: boolean) => {
    if (strictProxy) return 'React Native dev · dashboard Redis proxy';
    if (strictProxyOnlyFallback) {
      return 'React Native dev · strict proxy-only (dashboard unhealthy — local recording disabled)';
    }
    return 'React Native dev · hybrid (device + Metro)';
  };

  // Patch fetch for on / manual; launch_client when a launch lane id or launch scenario is present.
  const isEnabled = shouldActivateMockifyerForReactNative({
    runtimeMode: resolvedRuntimeMode,
    hasLaunchClientId: Boolean(clientIdFromLaunchArgs),
    hasLaunchScenario: launchScenarioApplied,
  });
  if (!isEnabled) {
    logMockifyerNotActivated(resolvedRuntimeMode, {
      launchClientIdKey,
      hadLaunchClientId: Boolean(clientIdFromLaunchArgs),
    });
    return { status: 'not_activated', instance: null } as const;
  }

  if (isDev === true) {
    const strictProxyEnabled = proxyBaseUrl
      ? skipDashboardRedisHealthCheck === true ||
        (await canUseDashboardRedisProxy(proxyBaseUrl))
      : false;

    const strictProxyOnlyFallback =
      Boolean(proxyBaseUrl?.trim()) &&
      !strictProxyEnabled &&
      resolveStrictScenarioResolution(mergedConfig);

    if (strictProxyOnlyFallback) {
      logger.warn(
        `[Mockifyer] Strict proxy-only: "${proxyBaseUrl}" did not report healthy Redis. ` +
          'Using memory provider without local recording. Start mockifyer-dashboard --provider redis ' +
          'or set skipDashboardRedisHealthCheck: true to force proxy.'
      );
    }

    // DEVELOPMENT MODE (React Native app running in dev)
    // Use Hybrid provider - saves to both device AND project folder simultaneously
    // Files are immediately available in project folder (no polling needed)
    // Note: The provider's initialize() is async and will be handled by the provider methods
    const metroPort = process.env.METRO_PORT ? parseInt(process.env.METRO_PORT, 10) : 8081;
    
    // Merge database provider config from options if provided
    const baseDatabaseProvider = {
      type: 'hybrid' as const,
      path: mockDataPath,
      options: {
        metroPort,
      },
    };

    // Merge with config.databaseProvider if provided
    const databaseProviderConfig = mergedConfig.databaseProvider 
      ? {
          ...baseDatabaseProvider,
          ...mergedConfig.databaseProvider,
          options: {
            ...baseDatabaseProvider.options,
            ...(mergedConfig.databaseProvider.options || {}),
            metroPort, // Always ensure metroPort is set
          },
        }
      : baseDatabaseProvider;

    const instance = setupMockifyer({
      mockDataPath,
      databaseProvider:
        strictProxyEnabled || strictProxyOnlyFallback
          ? {
              // Strict proxy source of truth: disable local mock lookup so all requests go through the dashboard proxy.
              type: 'memory',
            }
          : databaseProviderConfig,
      recordMode,
      useGlobalFetch: true,
      startDisabled,
      proxy:
        strictProxyEnabled && proxyBaseUrl
          ? {
              baseUrl: proxyBaseUrl,
              scenario: effectiveProxyScenario,
              recordOnMiss: proxyShouldRecordOnMiss,
              recordResponses: proxyShouldRecordResponses,
            }
          : undefined,
      ...(strictProxyEnabled
        ? {
            strictScenarioResolution: mergedConfig.strictScenarioResolution ?? true,
          }
        : {}),
      ...mergedConfig,
      ...(strictProxyOnlyFallback
        ? {
            databaseProvider: { type: 'memory' as const },
            intendedProxyBaseUrl: proxyBaseUrl!.trim(),
          }
        : {}),
      initLog: {
        headline:
          mergedConfig.initLog?.headline ??
          devInitHeadline(strictProxyEnabled, strictProxyOnlyFallback),
      },
    });

    if (!strictProxyEnabled && !strictProxyOnlyFallback) {
      logger.info(`[Mockifyer] Metro: http://localhost:${metroPort}/mockifyer-save · scenario: /mockifyer-scenario-config`);
    }

    if (!strictProxyEnabled && !strictProxyOnlyFallback) {
      // Pull repo mock-data onto device once Metro + provider are ready (HybridProvider.reload)
      try {
        await instance.reloadMockData(true);
      } catch (error) {
        logger.warn('[Mockifyer] Initial project→device sync failed (Metro running with built mockifyer-fetch?):', error);
      }
    }

    return { status: 'active', instance } as const;
  } else {
    // PRODUCTION BUILD MODE
    // Use Memory provider with bundled TypeScript file
    const provider = new MemoryProvider({});
    provider.initialize();

    // Load bundled mock data
    const mockDataArray = await loadBundledMockData(bundledDataPath);

    if (mockDataArray.length === 0) {
      logger.warn(
        '[Mockifyer] Activation requested but no bundled mock data found (status: failed_no_bundled_mocks). Run the bundle/generate step for your mocks.'
      );
      return { status: 'failed_no_bundled_mocks', instance: null } as const;
    }

    // Pre-load all mocks into memory
    for (const mockData of mockDataArray) {
      provider.save(mockData);
    }

    const instance = setupMockifyer({
      mockDataPath: './mock-data', // Not used with memory provider
      databaseProvider: {
        type: 'memory',
      },
      recordMode: false, // Can't record in production builds
      useGlobalFetch: true,
      startDisabled,
      proxy: proxyBaseUrl
        ? {
            baseUrl: proxyBaseUrl,
            scenario: effectiveProxyScenario,
            recordOnMiss: proxyShouldRecordOnMiss,
            recordResponses: proxyShouldRecordResponses,
          }
        : undefined,
      ...(proxyBaseUrl
        ? {
            strictScenarioResolution: mergedConfig.strictScenarioResolution ?? true,
          }
        : {}),
      ...mergedConfig,
      initLog: {
        headline:
          mergedConfig.initLog?.headline ??
          `React Native production · ${mockDataArray.length} bundled mock(s)`,
      },
    });

    return { status: 'active', instance } as const;
  }
}

/** React Native options with an explicit dashboard alias (see {@link initMockifyerForReactNativeDashboard}). */
export interface InitMockifyerForReactNativeDashboardOptions extends ReactNativeMockifyerConfig {
  /**
   * mockifyer-dashboard origin — same role as {@link ReactNativeMockifyerConfig.proxyBaseUrl}.
   * Useful when you prefer naming that matches the Node preset {@link initMockifyerForDashboardProxy}.
   */
  dashboardBaseUrl?: string;
}

/**
 * Preset: point the app at **mockifyer-dashboard** for `/api/proxy` (typically **`--provider redis`**).
 *
 * Resolves URL in order: **`proxyBaseUrl`** → **`dashboardBaseUrl`** → **`MOCKIFYER_PROXY_URL`** env.
 * Then delegates to {@link setupMockifyerForReactNative}. For bespoke wiring, call that helper directly.
 */
export async function initMockifyerForReactNativeDashboard(
  options: InitMockifyerForReactNativeDashboardOptions
): Promise<SetupMockifyerForReactNativeResult> {
  const fromEnv =
    typeof process !== 'undefined' && process.env?.MOCKIFYER_PROXY_URL
      ? process.env.MOCKIFYER_PROXY_URL.trim()
      : '';

  const resolved =
    String(options.proxyBaseUrl ?? '').trim() ||
    String(options.dashboardBaseUrl ?? '').trim() ||
    fromEnv;

  if (!resolved) {
    throw new Error(
      'initMockifyerForReactNativeDashboard: set proxyBaseUrl, dashboardBaseUrl, or MOCKIFYER_PROXY_URL'
    );
  }

  return setupMockifyerForReactNative({
    ...options,
    proxyBaseUrl: resolved,
  });
}

export {
  tryGetClientIdFromLaunchArguments,
  MOCKIFYER_LAUNCH_ARGUMENT_CLIENT_ID_KEY,
  getClientId,
  setClientId,
  registerMockifyerInstance,
  clearMockifyerClientIdRuntime,
} from '@sgedda/mockifyer-core';

