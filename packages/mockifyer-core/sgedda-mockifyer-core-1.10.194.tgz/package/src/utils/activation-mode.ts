import { ENV_VARS, type MockifyerActivationMode, type MockifyerConfig } from '../types';
import { getActiveInboundClientId } from './hop-context';
import { getOutboundHeaderValue } from './outbound-header';

/** Canonical outbound header: presence (non-empty) gates Mockifyer when `activationMode` is `client_id_header`. */
export const MOCKIFYER_CLIENT_ID_HEADER = 'x-mockifyer-client-id';

/** Canonical outbound device header (dashboard proxy + optional upstream propagation). */
export const MOCKIFYER_DEVICE_ID_HEADER = 'x-mockifyer-device-id';

/**
 * Reads `X-Mockifyer-Client-Id` from axios/fetch-style headers (plain object, AxiosHeaders, or Headers-like).
 */
export function getOutboundMockifyerClientIdHeader(headers: unknown): string | undefined {
  return getOutboundHeaderValue(headers, MOCKIFYER_CLIENT_ID_HEADER);
}

/**
 * Reads `X-Mockifyer-Device-Id` from axios/fetch-style headers (plain object, AxiosHeaders, or Headers-like).
 */
export function getOutboundMockifyerDeviceIdHeader(headers: unknown): string | undefined {
  return getOutboundHeaderValue(headers, MOCKIFYER_DEVICE_ID_HEADER);
}

/**
 * Whether Mockifyer handles this outbound request.
 *
 * With `client_id_header`, only the caller opts a request in: a non-empty `X-Mockifyer-Client-Id`
 * on the outbound request, or on the inbound request being served. The service's own
 * `clientId` / `proxy.baseUrl` never does — otherwise every request would be intercepted.
 */
export function shouldApplyMockifyer(mode: MockifyerActivationMode, requestHeaders: unknown): boolean {
  if (mode === 'off') {
    return false;
  }
  if (mode === 'always') {
    return true;
  }
  if (getOutboundMockifyerClientIdHeader(requestHeaders) !== undefined) {
    return true;
  }
  // Services with client_id_header often call downstream without copying the header
  // onto each client config. The inbound lane already opted this request in — activate
  // Mockifyer so hops can be logged / mocked. This does not start an inline trace.
  return Boolean(getActiveInboundClientId()?.trim());
}

/**
 * Resolves activation mode: env `MOCKIFYER_ACTIVATION_MODE` wins, then `config.activationMode`, then `always`.
 */
export function resolveActivationMode(config: Pick<MockifyerConfig, 'activationMode'>): MockifyerActivationMode {
  const raw =
    typeof process !== 'undefined' && process.env?.[ENV_VARS.MOCK_ACTIVATION_MODE]
      ? String(process.env[ENV_VARS.MOCK_ACTIVATION_MODE]).trim()
      : undefined;
  if (raw === 'always' || raw === 'client_id_header' || raw === 'off') {
    return raw;
  }
  const c = config.activationMode;
  if (c === 'always' || c === 'client_id_header' || c === 'off') {
    return c;
  }
  if (c !== undefined && c !== null && String(c).trim() !== '') {
    console.warn(
      `[Mockifyer] Unknown activationMode "${String(c)}", defaulting to "always". ` +
        `Valid: always | client_id_header | off`
    );
  }
  return 'always';
}
