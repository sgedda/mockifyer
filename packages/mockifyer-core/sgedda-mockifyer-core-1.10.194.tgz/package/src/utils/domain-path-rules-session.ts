import type { DomainPathRulesMode, MockifyerConfig } from '../types';
import {
  type DomainPathRulesMap,
  type DomainPathTrafficGate,
  discoverDomainPathRulesForUrl,
  mergeDiscoveredDomainPathUpserts,
  parseDomainPathRules,
  resolveDomainPathRulesMode,
  resolveDomainPathTrafficGate,
} from './domain-path-rules';
import { getCurrentScenario } from './scenario';
import { logger } from './logger';

/**
 * React Native / Metro often stubs `require('fs')` as `{}` without throwing.
 * Only treat Node fs as available when the sync APIs we need are real functions.
 */
let fsAvailable = false;
try {
  const nodeFs = require('fs') as Partial<typeof import('fs')>;
  fsAvailable =
    typeof nodeFs?.existsSync === 'function' &&
    typeof nodeFs?.readFileSync === 'function' &&
    typeof nodeFs?.writeFileSync === 'function' &&
    typeof nodeFs?.mkdirSync === 'function';
} catch {
  fsAvailable = false;
}

export interface DomainPathRulesSessionOptions {
  config: Pick<MockifyerConfig, 'mockDataPath' | 'domainPathRulesMode' | 'baseUrl' | 'clientId' | 'proxy' | 'databaseProvider'>;
  /** Metro port for RN Hybrid discovery writes (default 8081). */
  metroPort?: number;
  /** Override fetch used for Metro GET/POST (RN). */
  fetchFn?: typeof fetch;
  /**
   * When false, skip filesystem I/O and use Metro GET/POST (React Native Hybrid).
   * Defaults to whether `fs` is require-able in this runtime.
   */
  useFilesystem?: boolean;
  /**
   * Live `recordMode` from the Mockifyer instance. When false under allowlist mode,
   * discovery does not persist new keys. When true, discovery enables `recordResponses`.
   */
  getRecordMode?: () => boolean;
}

interface PendingDiscover {
  rawUrl: string;
  baseUrl?: string | null;
  /** Scenario active when the discover was queued (Metro hydrate may finish after a lane switch). */
  scenario: string;
}

/**
 * Per-Mockifyer-instance cache + discover/persist for domain-path rules (Hybrid/filesystem).
 * No-op when mode is `off` or dashboard proxy owns traffic.
 */
export class DomainPathRulesSession {
  private mode: DomainPathRulesMode;
  private rules: DomainPathRulesMap | null = null;
  private rulesScenario: string | null = null;
  /** File mtime (ms) at last disk load; `0` when the file was missing. Unused when not using fs. */
  private rulesMtimeMs: number | null = null;
  /** True once rules were loaded from disk or Metro (not merely an empty in-memory seed). */
  private rulesHydrated = false;
  private readonly config: DomainPathRulesSessionOptions['config'];
  private readonly metroPort: number;
  private readonly fetchFn: typeof fetch | undefined;
  private readonly useFs: boolean;
  private readonly getRecordMode: (() => boolean) | undefined;
  private persistQueue: Promise<void> = Promise.resolve();
  private hydratePromise: Promise<void> | null = null;
  /**
   * Bumped on every `invalidateCache()` so in-flight Metro GETs cannot commit
   * stale rules or flush discovers after a reload / scenario switch.
   */
  private hydrateGeneration = 0;
  private pendingDiscovers: PendingDiscover[] = [];

  constructor(options: DomainPathRulesSessionOptions) {
    this.mode = resolveDomainPathRulesMode({ configMode: options.config.domainPathRulesMode });
    this.config = options.config;
    this.metroPort =
      options.metroPort ??
      options.config.databaseProvider?.options?.metroPort ??
      (typeof process !== 'undefined' && process.env?.METRO_PORT
        ? parseInt(process.env.METRO_PORT, 10)
        : 8081);
    this.fetchFn = options.fetchFn;
    this.useFs = options.useFilesystem ?? fsAvailable;
    this.getRecordMode = options.getRecordMode;
  }

  getMode(): DomainPathRulesMode {
    return this.mode;
  }

  /** Change the domain-path gate mode at runtime. */
  setMode(mode: DomainPathRulesMode): void {
    this.mode = resolveDomainPathRulesMode({ configMode: mode });
  }

  private isRecording(): boolean {
    return this.getRecordMode?.() === true;
  }

  isActive(): boolean {
    return this.mode !== 'off' && !Boolean(this.config.proxy?.baseUrl?.trim());
  }

  /**
   * Turn `recordResponses: true` on every known rule for the active scenario and persist.
   * Used when enabling record mode so previously discovered allowlist `false` rows do not block saves.
   */
  enableRecordResponsesForAllRules(): void {
    if (!this.isActive()) {
      return;
    }
    const scenario = this.scenarioName();
    const rules = this.loadRules();
    let changed = false;
    const next: DomainPathRulesMap = {};
    for (const [key, rule] of Object.entries(rules)) {
      if (rule.recordResponses === true) {
        next[key] = rule;
        continue;
      }
      next[key] = { ...rule, recordResponses: true };
      changed = true;
    }
    if (!changed) {
      return;
    }
    this.rules = next;
    this.rulesScenario = scenario;
    this.persistQueue = this.persistQueue
      .then(async () => {
        await this.persistFullRules(next, scenario);
      })
      .catch((err) => {
        logger.warn('[Mockifyer] Domain path rules enable-record persist failed:', err);
      });
  }

  private scenarioName(): string {
    return getCurrentScenario(this.config.mockDataPath, this.config.clientId);
  }

  private resolveFetch(): typeof fetch | undefined {
    return this.fetchFn ?? (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : undefined);
  }

  private metroRulesUrl(scenario: string): string {
    return `http://localhost:${this.metroPort}/mockifyer-domain-path-rules?scenario=${encodeURIComponent(scenario)}`;
  }

  /**
   * Current on-disk mtime for the scenario rules file.
   * Returns `0` when the file does not exist, `null` when fs is unavailable.
   */
  private rulesFileMtimeMs(scenario: string): number | null {
    if (!this.useFs) {
      return null;
    }
    try {
      const { domainPathRulesFilePath } = require('./domain-path-rules-file') as typeof import('./domain-path-rules-file');
      const filePath = domainPathRulesFilePath(this.config.mockDataPath, scenario);
      if (!filePath) {
        return null;
      }
      const fs = require('fs') as Partial<typeof import('fs')>;
      if (typeof fs.existsSync !== 'function' || typeof fs.statSync !== 'function') {
        return null;
      }
      if (!fs.existsSync(filePath)) {
        return 0;
      }
      return fs.statSync(filePath).mtimeMs;
    } catch {
      return null;
    }
  }

  /**
   * Load authoritative rules from disk (Node) or Metro GET (RN Hybrid).
   * Call during startup (e.g. `reloadMockData`) so allowlist flags exist before traffic.
   */
  async hydrate(): Promise<void> {
    if (!this.isActive()) {
      this.rules = {};
      this.rulesScenario = this.scenarioName();
      this.rulesMtimeMs = null;
      this.rulesHydrated = true;
      return;
    }

    if (this.useFs) {
      const scenario = this.scenarioName();
      this.invalidateCache();
      this.loadRulesFromDisk(scenario);
      this.flushPendingDiscovers();
      return;
    }

    // Retry until a Metro hydrate commits for the current generation + scenario.
    // `invalidateCache()` (reloadMockData / lane switch) bumps generation while a
    // prior GET may still be in flight — awaiting that promise alone is not enough.
    for (;;) {
      const generation = this.hydrateGeneration;
      const scenario = this.scenarioName();

      if (
        this.rulesHydrated &&
        this.rulesScenario === scenario &&
        this.hydrateGeneration === generation
      ) {
        return;
      }

      if (this.hydratePromise) {
        await this.hydratePromise;
        if (
          this.rulesHydrated &&
          this.rulesScenario === scenario &&
          this.hydrateGeneration === generation
        ) {
          return;
        }
        // Invalidated or scenario changed while waiting — start a fresh hydrate.
        continue;
      }

      this.hydratePromise = this.hydrateFromMetro(scenario, generation);
      try {
        await this.hydratePromise;
      } finally {
        this.hydratePromise = null;
      }

      if (this.hydrateGeneration === generation && this.rulesHydrated && this.rulesScenario === scenario) {
        return;
      }
    }
  }

  private commitMetroHydrate(
    generation: number,
    scenario: string,
    loaded: DomainPathRulesMap
  ): boolean {
    if (generation !== this.hydrateGeneration) {
      return false;
    }
    if (this.scenarioName() !== scenario) {
      return false;
    }
    this.rules = loaded;
    this.rulesScenario = scenario;
    this.rulesMtimeMs = null;
    this.rulesHydrated = true;
    this.flushPendingDiscovers();
    return true;
  }

  private async hydrateFromMetro(scenario: string, generation: number): Promise<void> {
    const fetchFn = this.resolveFetch();
    if (!fetchFn) {
      logger.warn('[Mockifyer] Domain path rules: no fetch available to hydrate from Metro; starting empty');
      this.commitMetroHydrate(generation, scenario, {});
      return;
    }

    try {
      const res = await fetchFn(this.metroRulesUrl(scenario), { method: 'GET' });
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        logger.warn(`[Mockifyer] Domain path rules Metro hydrate HTTP ${res.status}: ${text}`);
        // Keep any newer in-memory map from a later generation; otherwise seed empty.
        const fallback = generation === this.hydrateGeneration ? (this.rules ?? {}) : {};
        this.commitMetroHydrate(generation, scenario, fallback);
        return;
      }
      const parsed = (await res.json()) as { success?: boolean; rules?: unknown };
      const loaded =
        parsed.success && parsed.rules != null
          ? parseDomainPathRules(parsed.rules)
          : {};
      this.commitMetroHydrate(generation, scenario, loaded);
    } catch (err) {
      logger.warn('[Mockifyer] Domain path rules Metro hydrate failed:', err);
      const fallback = generation === this.hydrateGeneration ? (this.rules ?? {}) : {};
      this.commitMetroHydrate(generation, scenario, fallback);
    }
  }

  private ensureMetroHydrate(): void {
    if (this.useFs) {
      return;
    }
    const scenario = this.scenarioName();
    if (this.rulesHydrated && this.rulesScenario === scenario) {
      return;
    }
    // Always kick hydrate() — it coalesces in-flight work and retries after invalidate.
    void this.hydrate().catch((err) => {
      logger.warn('[Mockifyer] Domain path rules background hydrate failed:', err);
    });
  }

  private flushPendingDiscovers(): void {
    if (this.pendingDiscovers.length === 0) {
      return;
    }
    const activeScenario = this.scenarioName();
    const pending = this.pendingDiscovers;
    this.pendingDiscovers = [];
    for (const item of pending) {
      // Drop discovers queued under a different scenario (lane switch / reload).
      if (item.scenario !== activeScenario) {
        continue;
      }
      this.discover(item.rawUrl, item.baseUrl);
    }
  }

  private loadRulesFromDisk(scenario: string): DomainPathRulesMap {
    let loaded: DomainPathRulesMap = {};
    const mtimeMs = this.rulesFileMtimeMs(scenario);
    try {
      const { readDomainPathRulesFile } = require('./domain-path-rules-file') as typeof import('./domain-path-rules-file');
      loaded = readDomainPathRulesFile(this.config.mockDataPath, scenario);
    } catch {
      loaded = {};
    }
    this.rules = loaded;
    this.rulesScenario = scenario;
    this.rulesMtimeMs = mtimeMs;
    this.rulesHydrated = true;
    return loaded;
  }

  private loadRules(): DomainPathRulesMap {
    const scenario = this.scenarioName();

    if (this.useFs) {
      const mtimeMs = this.rulesFileMtimeMs(scenario);
      const cacheHit =
        this.rules !== null &&
        this.rulesScenario === scenario &&
        mtimeMs !== null &&
        mtimeMs === this.rulesMtimeMs;
      if (cacheHit) {
        return this.rules!;
      }
      return this.loadRulesFromDisk(scenario);
    }

    // React Native Hybrid: never treat an empty in-memory map as authoritative.
    // Existing project rules live on disk and must be loaded via Metro GET first.
    if (this.rules && this.rulesScenario === scenario && this.rulesHydrated) {
      return this.rules;
    }
    if (this.rulesScenario !== scenario) {
      this.rules = null;
      this.rulesHydrated = false;
      this.rulesScenario = null;
      this.rulesMtimeMs = null;
    }
    this.ensureMetroHydrate();
    return this.rules ?? {};
  }

  /** Drop the in-memory rules map so the next gate/discover reloads from disk (or Metro). */
  invalidateCache(): void {
    this.rules = null;
    this.rulesScenario = null;
    this.rulesMtimeMs = null;
    this.rulesHydrated = false;
    // Bump generation so in-flight Metro GETs cannot commit after this point.
    // Keep `hydratePromise` so awaiters can finish, then `hydrate()` retries.
    this.hydrateGeneration += 1;
    // Pending discovers are scenario-pinned; drop them so a reload cannot replay
    // traffic from the previous cache generation into the new rules document.
    this.pendingDiscovers = [];
  }

  /**
   * Resolve record/replay gate for a URL. When inactive, always allows.
   */
  getTrafficGate(rawUrl: string | null | undefined, baseUrl?: string | null): DomainPathTrafficGate {
    if (!this.isActive()) {
      return { mayRecord: true, mayReplay: true, matchedDomainPath: null, matchedRule: null };
    }
    const rules = this.loadRules();
    return resolveDomainPathTrafficGate(
      rawUrl,
      rules,
      this.mode,
      baseUrl ?? this.config.baseUrl
    );
  }

  /**
   * Enable autoMock for a URL (allows replay). Called after saving an allowlisted response.
   */
  enableAutoMockForUrl(rawUrl: string | null | undefined, baseUrl?: string | null): void {
    if (!this.isActive() || !rawUrl) {
      return;
    }

    const { endpointUrlToDomainPath } = require('./domain-path-rules') as typeof import('./domain-path-rules');
    const resolved = typeof rawUrl === 'string' ? rawUrl.trim() : '';
    if (!resolved) {
      return;
    }

    let absoluteUrl = resolved;
    if (baseUrl && !/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(resolved)) {
      try {
        absoluteUrl = new URL(resolved, baseUrl).href;
      } catch {
        // If URL construction fails, use the original
      }
    }

    const domainPath = endpointUrlToDomainPath(absoluteUrl);
    if (!domainPath) {
      return;
    }

    const scenario = this.scenarioName();
    const rules = this.loadRules();
    const existing = rules[domainPath];
    if (!existing) {
      // No rule exists yet; this shouldn't happen since discover should have created it
      return;
    }

    if (existing.autoMock === true) {
      // Already enabled
      return;
    }

    // Update the rule to enable autoMock
    const updated: DomainPathRulesMap = { ...rules };
    updated[domainPath] = { ...existing, autoMock: true, updatedAt: new Date().toISOString() };
    this.rules = updated;
    this.rulesScenario = scenario;

    // Persist to disk
    if (this.useFs) {
      this.persistQueue = this.persistQueue.then(async () => {
        await this.persistFullRules(updated, scenario);
      }).catch((err) => {
        logger.warn('[DomainPathRules] Failed to persist autoMock update:', err);
      });
    }
  }

  /**
   * Upsert discovered domain/path keys and persist (Node fs or Metro POST).
   * Fire-and-forget safe; errors are logged.
   */
  discover(rawUrl: string | null | undefined, baseUrl?: string | null): void {
    if (!this.isActive() || !rawUrl) {
      return;
    }

    const recording = this.isRecording();
    // Allowlist + not recording: repair existing deny seeds under an allowing parent,
    // but do not insert new keys (those `recordResponses: false` rows later block Record).
    const repairOnly = this.mode === 'allowlist' && !recording;

    // Without fs, wait for Metro hydrate so discovery does not seed allowlist
    // defaults over project rules that are enabled on disk.
    // Require hydrate for the *active* scenario — a prior lane's cache is not enough.
    const activeScenario = this.scenarioName();
    if (!this.useFs && !(this.rulesHydrated && this.rulesScenario === activeScenario)) {
      this.pendingDiscovers.push({
        rawUrl,
        baseUrl,
        scenario: activeScenario,
      });
      this.ensureMetroHydrate();
      return;
    }

    const scenarioAtDiscover = this.scenarioName();
    const rules = this.loadRules();
    const beforeKeys = Object.keys(rules).length;
    const { changed, upserted } = discoverDomainPathRulesForUrl(
      rules,
      rawUrl,
      this.mode,
      baseUrl ?? this.config.baseUrl,
      { recording, repairOnly }
    );
    if (!changed) {
      return;
    }
    this.rules = rules;
    this.rulesScenario = scenarioAtDiscover;

    const upsertMap: DomainPathRulesMap = {};
    for (const key of upserted) {
      const rule = rules[key];
      if (rule) {
        upsertMap[key] = rule;
      }
    }

    // Capture scenario at discover time — persist may run after scenario/lane switches.
    this.persistQueue = this.persistQueue
      .then(async () => {
        await this.persistUpserts(upsertMap, scenarioAtDiscover);
      })
      .catch((err) => {
        logger.warn('[Mockifyer] Domain path rules discover persist failed:', err);
      });

    if (upserted.length > 0) {
      logger.debug(
        `[Mockifyer] Domain path rules discovered (+${upserted.length}, total keys ${beforeKeys + upserted.length}): ${upserted.join(', ')}`
      );
    }
  }

  /**
   * Persist discovery upserts by merging onto on-disk/Metro rules for `scenario`
   * (the scenario captured at discover time, not whatever is active now).
   * Never prefer the in-memory full map by key count — that can overwrite
   * concurrent dashboard/external edits when key counts are similar.
   * Only refreshes the in-memory cache when the active scenario still matches.
   */
  private async persistUpserts(upsertMap: DomainPathRulesMap, scenario: string): Promise<void> {
    if (this.useFs) {
      try {
        const {
          readDomainPathRulesFile,
          writeDomainPathRulesFile,
        } = require('./domain-path-rules-file') as typeof import('./domain-path-rules-file');
        const onDisk = readDomainPathRulesFile(this.config.mockDataPath, scenario);
        const merged = mergeDiscoveredDomainPathUpserts(onDisk, upsertMap);
        const wrote =
          !merged.changed ||
          writeDomainPathRulesFile(this.config.mockDataPath, scenario, merged.rules);
        if (wrote) {
          if (this.scenarioName() === scenario) {
            this.rules = merged.rules;
            this.rulesScenario = scenario;
            this.rulesMtimeMs = this.rulesFileMtimeMs(scenario);
            this.rulesHydrated = true;
          }
          return;
        }
        // Stubbed/empty `fs` (e.g. RN Metro) — fall through to Metro POST.
      } catch (err) {
        logger.warn('[Mockifyer] Domain path rules file write failed:', err);
      }
    }

    await this.postMetroRules({
      scenario,
      upserts: upsertMap,
      mode: this.mode,
    });
  }

  /** Replace the full rules map on disk / Metro (used when enabling record on existing keys). */
  private async persistFullRules(rules: DomainPathRulesMap, scenario: string): Promise<void> {
    if (this.useFs) {
      try {
        const {
          readDomainPathRulesFile,
          writeDomainPathRulesFile,
        } = require('./domain-path-rules-file') as typeof import('./domain-path-rules-file');
        // Re-read from disk to pick up any concurrent new keys, then apply recordResponses updates.
        const onDisk = readDomainPathRulesFile(this.config.mockDataPath, scenario);
        const merged: DomainPathRulesMap = { ...rules };
        // Add any new keys that were discovered concurrently but preserve the recordResponses updates.
        for (const [key, rule] of Object.entries(onDisk)) {
          if (!merged[key]) {
            merged[key] = { ...rule };
          }
        }
        const wrote = writeDomainPathRulesFile(this.config.mockDataPath, scenario, merged);
        if (wrote) {
          if (this.scenarioName() === scenario) {
            this.rules = merged;
            this.rulesScenario = scenario;
            this.rulesMtimeMs = this.rulesFileMtimeMs(scenario);
            this.rulesHydrated = true;
          }
          return;
        }
      } catch (err) {
        logger.warn('[Mockifyer] Domain path rules full write failed:', err);
      }
    }

    // Metro: use a custom merge that preserves the recordResponses updates.
    await this.postMetroRules({
      scenario,
      rules,
      replace: true,
      mode: this.mode,
    });
  }

  private async postMetroRules(body: {
    scenario: string;
    upserts?: DomainPathRulesMap;
    rules?: DomainPathRulesMap;
    replace?: boolean;
    mode: DomainPathRulesMode;
  }): Promise<void> {
    const fetchFn = this.resolveFetch();
    if (!fetchFn) {
      return;
    }
    const metroUrl = `http://localhost:${this.metroPort}/mockifyer-domain-path-rules`;
    const res = await fetchFn(metroUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      logger.warn(`[Mockifyer] Domain path rules Metro persist HTTP ${res.status}: ${text}`);
      return;
    }
    try {
      const parsed = (await res.json()) as { success?: boolean; rules?: DomainPathRulesMap };
      if (parsed.success && parsed.rules && typeof parsed.rules === 'object') {
        if (this.scenarioName() === body.scenario) {
          this.rules = parseDomainPathRules(parsed.rules);
          this.rulesScenario = body.scenario;
          this.rulesMtimeMs = null;
          this.rulesHydrated = true;
        }
      }
    } catch {
      // ignore non-JSON
    }
  }
}
