import type { MockData, MockifyerConfig } from '../types';
import { applyCapturedResponse } from './request-only-mock';
import { applyResponseDateOverridesToData } from './mock-response-date-overrides';
import {
  applyResponseFieldOverridesToData,
  mockHasResponseFieldOverrides,
} from './mock-response-field-overrides';
import {
  activeOverrideGroupHasEntry,
  applyActiveOverrideGroupOverlays,
} from './override-group-runtime';
import { resolveRefreshPassthroughRecordings } from './record-passthrough-env';

/** How a matched mock is served on the next outbound request. */
export type MockReplayMode = 'stored' | 'refresh-next' | 'always-refresh' | 'passthrough';

/**
 * Resolves replay behavior for a mock recording.
 *
 * - `stored` — serve saved body (+ optional date overrides).
 * - `refresh-next` — one upstream fetch, update stored body, clear flag, return live (+ overrides).
 * - `always-refresh` — every request fetches upstream, updates stored body, returns live (+ overrides).
 * - `passthrough` — live API (`alwaysUseRealApi` / `responsePending` with no other mode set).
 *
 * Explicit refresh flags win over `responsePending` so dashboard mode changes on
 * request-only stubs take effect before a body is captured.
 */
export function resolveMockReplayMode(mockData: MockData): MockReplayMode {
  if (mockData.alwaysRefreshFromLive === true) {
    return 'always-refresh';
  }
  if (mockData.refreshOnNextRequest === true) {
    return 'refresh-next';
  }
  if (mockData.alwaysUseRealApi === true || mockData.responsePending === true) {
    return 'passthrough';
  }
  return 'stored';
}

/** True when the outbound request must call the real upstream instead of serving the stored body. */
export function mockRequiresUpstreamFetch(mockData: MockData): boolean {
  return resolveMockReplayMode(mockData) !== 'stored';
}

/** True when the stored mock body should be returned without calling upstream. */
export function mockShouldServeStoredBody(mockData: MockData): boolean {
  return resolveMockReplayMode(mockData) === 'stored';
}

/** True when the mock has date overrides configured on response paths. */
export function mockHasResponseDateOverrides(mockData: MockData): boolean {
  return Array.isArray(mockData.responseDateOverrides) && mockData.responseDateOverrides.length > 0;
}

/**
 * Whether a mock should participate in request matching (exact / similar).
 *
 * Passthrough mocks are normally skipped so traffic hits upstream anonymously; they are included when
 * passthrough mocks carry overrides (live response patching), the active override group has an entry
 * for `filename`, or when callers set `includePassthroughMocks`.
 */
export function mockShouldBeIncludedInRequestMatch(
  mockData: MockData,
  options?: {
    includePassthroughMocks?: boolean;
    filename?: string;
    scenarioPath?: string;
    overrideGroupId?: string | null;
  }
): boolean {
  if (options?.includePassthroughMocks === true) {
    return true;
  }
  if (resolveMockReplayMode(mockData) === 'passthrough') {
    return (
      mockHasResponseDateOverrides(mockData) ||
      mockHasResponseFieldOverrides(mockData) ||
      (typeof options?.filename === 'string' &&
        options.filename.trim().length > 0 &&
        activeOverrideGroupHasEntry(
          options.filename,
          options.scenarioPath,
          options.overrideGroupId
        ))
    );
  }
  return true;
}

/**
 * Whether a successful upstream response should overwrite the stored mock corpus entry.
 *
 * Refresh modes always persist. Passthrough persists only when global refresh passthrough is enabled.
 */
export function resolveShouldPersistLiveCapture(
  mockData: MockData,
  config: Pick<MockifyerConfig, 'refreshPassthroughRecordings'>
): boolean {
  const mode = resolveMockReplayMode(mockData);
  if (mode === 'refresh-next' || mode === 'always-refresh') {
    return true;
  }
  if (mode === 'passthrough') {
    return resolveRefreshPassthroughRecordings(config);
  }
  return false;
}

/** Applies upstream capture to mock metadata (raw body, timestamp, clears one-shot refresh flag). */
export function applyLiveFetchMockUpdates(
  mockData: MockData,
  capturedResponse: MockData['response'],
  durationMs?: number
): void {
  applyCapturedResponse(mockData, capturedResponse);
  mockData.timestamp = new Date().toISOString();
  if (durationMs !== undefined) {
    mockData.duration = durationMs;
  }
  if (mockData.refreshOnNextRequest === true) {
    delete mockData.refreshOnNextRequest;
  }
}

/**
 * Clones upstream response and applies mock-level + active override-group overlays for the client.
 * Pass `filename` so group overlays apply (including when the mock itself has none).
 */
export function buildClientResponseFromLiveCapture(
  mockData: MockData,
  capturedResponse: MockData['response'],
  getNow: () => Date,
  options?: { filename?: string; scenarioPath?: string; overrideGroupId?: string | null }
): MockData['response'] {
  const filename = options?.filename;
  const hasDate = mockHasResponseDateOverrides(mockData);
  const hasField = mockHasResponseFieldOverrides(mockData);
  const hasGroup =
    typeof filename === 'string' &&
    filename.trim().length > 0 &&
    activeOverrideGroupHasEntry(filename, options?.scenarioPath, options?.overrideGroupId);

  if (!hasDate && !hasField && !hasGroup) {
    return capturedResponse;
  }

  let data = capturedResponse.data;
  if (hasField) {
    data = applyResponseFieldOverridesToData(data, mockData.responseFieldOverrides ?? []);
  }
  if (hasDate) {
    data = applyResponseDateOverridesToData(data, mockData.responseDateOverrides ?? [], getNow);
  }
  data = applyActiveOverrideGroupOverlays(
    data,
    filename,
    getNow,
    options?.scenarioPath,
    options?.overrideGroupId
  );

  return {
    ...capturedResponse,
    data,
  };
}

/** Deep-clones mock, applies live capture fields, for safe persistence. */
export function buildMockDataAfterLiveCapture(
  mockData: MockData,
  capturedResponse: MockData['response'],
  durationMs?: number
): MockData {
  const updated: MockData = JSON.parse(JSON.stringify(mockData)) as MockData;
  applyLiveFetchMockUpdates(updated, capturedResponse, durationMs);
  return updated;
}

/**
 * True when the mock has a captured response body (not a request-only stub).
 * Checks the durable response shape instead of `responsePending` flag.
 */
function mockHasCapturedBody(mockData: MockData): boolean {
  return mockData.response.status !== 0 || mockData.response.data !== null;
}

/**
 * Applies a mutually exclusive replay mode to a mock recording.
 *
 * Request-only stubs (`responsePending`) stay on live API until a mode other than
 * passthrough is chosen. Leaving passthrough clears `responsePending` so matching
 * and the dashboard radio reflect the new mode. `stored` with no captured body
 * becomes `refresh-next` so the next request records a response instead of serving empty JSON.
 */
export function applyMockReplayModeSetting(mockData: MockData, mode: MockReplayMode): void {
  delete mockData.alwaysUseRealApi;
  delete mockData.refreshOnNextRequest;
  delete mockData.alwaysRefreshFromLive;

  const pendingWithoutBody = mockData.responsePending === true || !mockHasCapturedBody(mockData);
  const resolvedMode =
    mode === 'stored' && pendingWithoutBody ? 'refresh-next' : mode;

  if (resolvedMode !== 'passthrough' && pendingWithoutBody) {
    delete mockData.responsePending;
  }

  switch (resolvedMode) {
    case 'passthrough':
      mockData.alwaysUseRealApi = true;
      break;
    case 'refresh-next':
      mockData.refreshOnNextRequest = true;
      break;
    case 'always-refresh':
      mockData.alwaysRefreshFromLive = true;
      break;
    case 'stored':
    default:
      break;
  }
}
